package backery;



import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
public class Sales extends JFrame {
	PreparedStatement pr;
	static   Connection con;
	String url="jdbc:mysql://localhost:3306/back_db";
    ResultSet rst;
	
	JLabel tr_id,p_name,qantity, total_amount,t_date;
	JButton create,update,delete,search,cancel;
	JTextField text_tr_id, text_p_name, text_quantity,text_total_amount,text_t_date;
	
	JPanel panel=new JPanel();
	
	
	
	public Sales() {
		this.setTitle("Insert the sales");
		// these are label of the textfields
		tr_id=new JLabel("tr_id:");
		p_name=new JLabel("p_name:");
		qantity=new JLabel("qantity:");
		total_amount=new JLabel("total_amount:");
		t_date=new JLabel("t_date:");
		
		
		// these are textfields where we will type information
		text_tr_id=new JTextField();
		text_p_name=new JTextField();
		text_quantity=new JTextField();
		text_total_amount=new JTextField();
		text_t_date=new JTextField();
		
		
		// these are button for doing actions
		create=new JButton("create");
		update=new JButton("Update");
		delete=new JButton("Delete");
		search=new JButton("Search");
		cancel=new JButton("Cancel");
		
		tr_id.setBounds(20,20,150,20);
		p_name.setBounds(20,45,150,20);
		qantity.setBounds(20,70,150,20);
		total_amount.setBounds(20,95,150,20);
		t_date.setBounds(20,120,150,20);
		
		text_tr_id.setBounds(140,20,150,20);
		text_p_name.setBounds(140,45,150,20);
		text_quantity.setBounds(140,70,150,20);
		text_total_amount.setBounds(140,95,150,20);
		text_t_date.setBounds(140,120,150,20);
		
		create.setBounds(20,230,80,30);
		update.setBounds(110,230,80,30);
		delete.setBounds(200,230,80,30);
		search.setBounds(290,230,80,30);
		cancel.setBounds(380,230,80,30);
		// add content to the panel
		panel.setLayout(null);
		panel.setBackground(Color.green);
		panel.add(tr_id);
		panel.add(p_name);
		panel.add(qantity);
		panel.add(total_amount);
		panel.add(t_date);
		
		panel.add(text_tr_id);
		panel.add(text_p_name);
		panel.add(text_quantity);
		panel.add(text_total_amount);
		panel.add(text_t_date);
		
		
		
		panel.add(create);
		panel.add(search);
		panel.add(update);
		panel.add(delete);
		panel.add(cancel);
		 getContentPane().add(panel);
		this.setSize(500,330);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				insert();
								
			}
		});
		search.addActionListener(new ActionListener() {//this is an event of clicking the button search
			
			@Override
			public void actionPerformed(ActionEvent e) {
				select();// this is a function call of selecting from the database
								
			}
		});
     update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
								
			}
		});
    delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				delete();
								
			}
		});
	cancel.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			new Mysales();
			dispose();
			
		}
	});
	}
	
	 public void insert(){// function for inserting a new product
		 String sql1="INSERT INTO sales(tr_id, p_name, quantity, total_amount, t_date)"+ "VALUES(?,?,?,?,?)";
	                
	      
	        try {	              
	        	con=DriverManager.getConnection(url,"root","");
                pr=con.prepareStatement(sql1);  
	              
	            pr.setString(1,text_tr_id.getText());
	            pr.setString(2,text_p_name.getText());
	            pr.setString(3,text_quantity.getText());
	            pr.setString(4,text_total_amount.getText());
	            pr.setString(5,text_t_date.getText());
	           
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
	 public void select(){// function of searching a product
	       
         try {
               String slct="SELECT *FROM sales WHERE tr_id='"+text_tr_id.getText()+"'";
             con=DriverManager.getConnection(url,"root","");
            
             pr=con.prepareStatement(slct);
             rst=pr.executeQuery();
           
             if(rst.next()){                   
            	 text_tr_id.setText(rst.getString("tr_id"));
            	 text_p_name.setText(rst.getString("p_name"));
            	 text_quantity.setText(rst.getString("quantity"));
            	 text_total_amount.setText(rst.getString("total_amount"));
            	 text_t_date.setText(rst.getString("t_date"));
                  
             }
             else {
            	 JOptionPane.showMessageDialog(null,"Searched Record name found!!");
             }
       } catch (Exception e) {
             System.out.println(e);
        }
    }
public void delete(){// function for deleting a product
         
         String sql="DELETE from sales where tr_id='"+ text_tr_id.getText()+"'";
         
         PreparedStatement pr;
        try {
            con=DriverManager.getConnection(url,"root","");
            pr = con.prepareStatement(sql);
              
              if(pr.execute()) {
            	  JOptionPane.showMessageDialog(null,"wow deleted succefully!!");
              }
              else {
            	  JOptionPane.showMessageDialog(null,"Record not found!!");
              }
             
              
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"Not Deleted!!");
        }

}
public void update(){// function for updating a worker
    
    
    String upd="UPDATE sales SET quantity=?"
            + ",tr_id=?"
            + ",total_amount=? "
            + ",t_date=? WHERE p_name=?";
          
    try {
        con=DriverManager.getConnection(url,"root","");
        pr=con.prepareStatement(upd);
        
        pr.setString(1,text_tr_id.getText());
        pr.setString(2, text_p_name.getText());
        pr.setString(3,text_quantity.getText());
        pr.setString(4, text_total_amount.getText());
        pr.setString(5,text_t_date.getText());
       
    
        JOptionPane openJ=new JOptionPane();
        int showJ=openJ.showConfirmDialog(null,"Dou you want to Update this Record","UPDATE",
                JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(showJ==JOptionPane.OK_OPTION){
            pr.executeUpdate();
            JOptionPane.showMessageDialog(null,"UPDATED Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
        	 JOptionPane.showMessageDialog(null,"Update cancelled Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e);
    }
}}


