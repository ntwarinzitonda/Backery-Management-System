package backery;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import backery.Mymanager;

public class Ingredient extends JFrame {
	

	 static Connection con = null;
	    PreparedStatement pr=null;
	     String user="Root";
	         String pass ="";
	         String url="jdbc:mysql://localhost:3306/back_db";
	         ResultSet rst;
	JLabel ing_id,name,supplier,unit,price,quantity;
	JButton create,upsupplier,delete,search,cancel;
	JTextField text_ing_id, text_name, text_supplier, text_price,text_quantity;
	JComboBox text_unit=new JComboBox();
	//JComboBox text_quantity=new JComboBox();
	JPanel panel=new JPanel();
	
	
	public Ingredient() {
		this.setTitle("my order form");
		// these are label of the textfields
		ing_id=new JLabel("ing_id:");
		name=new JLabel("name:");
		supplier=new JLabel("supplier:");
		unit=new JLabel("unit:");
		price=new JLabel("price:");
		quantity=new JLabel("quantity");
		//password=new JLabel("Password");
		//workers_id=new JLabel("workers_id");
		// these are textfields where we will type information
		text_ing_id=new JTextField();
		text_name=new JTextField();
		text_supplier=new JTextField();
		text_price=new JTextField();
		text_quantity=new JTextField();
		//text_price=new JTextField();
		//text_quantity=new JTextField();
		//text_workers_id=new JTextField();
		text_unit.addItem("grams");
		text_unit.addItem("kilograms");
		
		//text_quantity.addItem("deliverd");
		//text_quantity.addItem("progress");
		//text_type.addItem("cooker");
		//text_type.addItem("waiter");
		
		
		// these are button for doing actions
		create=new JButton("create");
		upsupplier=new JButton("Upsupplier");
		delete=new JButton("Delete");
		search=new JButton("Search");
		cancel=new JButton("Cancel");
		ing_id.setBounds(20,20,150,20);
		name.setBounds(20,45,150,20);
		supplier.setBounds(20,70,150,20);
		unit.setBounds(20,95,150,20);
		price.setBounds(20,120,150,20);
		quantity.setBounds(20,145,150,20);
		//password.setBounds(20,170,150,20);
		//workers_id.setBounds(20,195,150,20);
		
		 text_ing_id.setBounds(140,20,150,20);
		 text_name.setBounds(140,45,150,20);
		 text_supplier.setBounds(140,70,150,20);
		 text_unit.setBounds(140,95,150,20);
		 text_price.setBounds(140,120,150,20);
		 text_quantity.setBounds(140,145,150,20);
		//text_password.setBounds(140,170,150,20);
		//text_workers_id.setBounds(140,195,150,20);
	
		create.setBounds(20,300,80,30);
		upsupplier.setBounds(110,300,80,30);
		delete.setBounds(200,300,80,30);
		search.setBounds(290,300,80,30);
		cancel.setBounds(380,300,80,30);
		
		//getting information from the interface
		
		text_ing_id.getText();
		text_name.getText();
		text_supplier.getText();
		text_unit.getSelectedItem();
		text_price.getText();
		text_quantity.getText();
		
		//text_quantity.getSelectedText();
		//text_password.getText();
		//text_workers_id.getText();
		
		  create.addActionListener(new ActionListener() {// creating a ingredient
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                 insert();
	                }
	         });
		  
		  search.addActionListener(new ActionListener() {// searching record
	            @Override
	            public void actionPerformed(ActionEvent e) {
	               select();
	            
	            }
	        });
	      
	           upsupplier.addActionListener(new ActionListener() {//updating record
	            @Override
	            public void actionPerformed(ActionEvent e) {
	               
	             upsupplier();
	            }
	        });
	           cancel.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					new Mymanager();
					dispose();
					
				}
			});
	          
	       
	           delete.addActionListener(new ActionListener() {
	               @Override
	               public void actionPerformed(ActionEvent e) {
	                   try {
	                         delete();
	                         text_ing_id.setText(null);
	                         text_name.setText(null);
	                         text_supplier.setText(null);
	                         text_price.setText(null);
	                          text_unit.setSelectedItem(null);
	                         text_quantity.setText(null);
	                             // text_password.setText(null);
	                             // text_workers_id.setText(null);

	                   } 
	                   catch (Exception ex) {
	                       System.out.println("Invalide");
	                   }
	                 
	               }
	           });
		
		
		
		
		
		// add content to the panel
		panel.setLayout(null);
		panel.setBackground(Color.green);
		panel.add(ing_id);
		panel.add(name);
		panel.add(supplier);
		panel.add(unit);
		panel.add(price);
		panel.add(quantity);
		
		panel.add(text_ing_id);
		panel.add(text_name);
		panel.add(text_supplier);
		panel.add(text_unit);
		panel.add(text_price);
		panel.add(text_quantity);
		//panel.add(username);
		//panel.add(password);
		//panel.add(text_username);
		//panel.add(text_password);
		
		panel.add(create);
		panel.add(search);
		panel.add(upsupplier);
		panel.add(delete);
		panel.add(cancel);
		 getContentPane().add(panel);
		this.setSize(500,380);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	 public void insert(){// function for inserting a new order
	      
	        try {
	              
	          String sql="INSERT INTO ingredient(ing_id, name, supplier, unit, price, quantity)" + "VALUES(?,?,?,?,?,?)";
	               
	         
	              con=DriverManager.getConnection(url,"root",""); 
	           pr= con.prepareStatement(sql);
	            pr.setString(1,text_ing_id.getText());
	            pr.setString(2,text_name.getText());
	            pr.setString(3,text_supplier.getText());
	           pr.setString(4,text_unit.getSelectedItem().toString());
	            pr.setString(5,text_price.getText());
	           pr.setString(6,text_quantity.getText());
	           // pr.setString(7,text_password.getText());
	           // pr.setString(8,text_workers_id.getText());
	           
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
	 public void select(){// function of searching a order
		
		String show;
         try {
               String slct="SELECT *FROM ingredient WHERE name='"+text_name.getText()+"'";
             con=DriverManager.getConnection(url,"root","");
            
             pr=con.prepareStatement(slct);
             rst=pr.executeQuery();
           
             while(rst.next()){                   
            	 text_ing_id.setText(rst.getString("id"));
            	 text_name.setText(rst.getString("name"));
            	 text_supplier.setText(rst.getString("supplier"));
            	 text_price.setText(rst.getString("price"));
            	 text_quantity.setText(rst.getString("quantity"));
                   show=rst.getString("unit");
                   text_unit.addItem(show);
                   //show=rst.getString("quantity");
                   //text_quantity.addItem(show);
                   
                      //text_password.setText(rst.getString("Password"));
                      //text_workers_id.setText(rst.getString("workers_id"));

             }
       } catch (Exception e) {
             System.out.println(e);
        }
    }
	 public void delete(){// function for deleting a order
         
         String sql="DELETE from ingredient where ing_id='"+text_ing_id.getText()+"'";
         
         PreparedStatement pr;
        try {
            con=DriverManager.getConnection(url,"root","");
            pr = con.prepareStatement(sql);
              pr.execute();
              JOptionPane.showMessageDialog(null,"value deleted succefully!!");
              
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null," value Not Deleted!!");
        }
       
    }
	    public void upsupplier(){// function for updating a order
	    	 String sql2="UPsupplier order SET ing_id=?, name=?, supplier=?, unit=?, price=? ,  quantity=?WHERE ing_id=?";
	           
	            String upd="UPsupplier order SET "
	                    + "ing_id=?,"
	                    + "name=?,"
	                    + "supplier=?,unit=?,"
	                    + "price=?,quantity=?,"
	                    + "WHERE ing_id=?";
	            try {
	                con=DriverManager.getConnection(url,"root","");
	                pr=con.prepareStatement(upd);
	                
	              
	                pr.setString(1,text_ing_id.getText());
		            pr.setString(2,text_name.getText());
		            pr.setString(3,text_supplier.getText());
		           
		            
		            pr.setString(4,text_unit.getSelectedItem().toString());
		            pr.setString(5,text_price.getText());
		            pr.setString(6,text_price.getText());
		            //pr.setString(6,text_quantity.getSelectedItem().toString());
		            //pr.setString(7,text_password.getText());
		           // pr.setString(8,text_workers_id.getText());
		           
	            
	         
	             
	            
	                JOptionPane openJ=new JOptionPane();
	                int showJ=openJ.showConfirmDialog(null,"Dou you want to Upsupplier this Record","UPsupplier",
	                        JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
	                if(showJ==JOptionPane.OK_OPTION){
	                    pr.executeUpdate();
	                    JOptionPane.showMessageDialog(null,"UPsupplierD Successfully","UPsupplier",JOptionPane.INFORMATION_MESSAGE);
	                }
	                else {
	                	 JOptionPane.showMessageDialog(null,"Upsupplier cancelled Successfully","UPsupplier",JOptionPane.INFORMATION_MESSAGE);
	                }
	                
	            } catch (Exception e) {
	                JOptionPane.showMessageDialog(null,e);
	            }
	        
	    }
	 
    

}

