package backery;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
public class Product extends JFrame {
	PreparedStatement pr;
	static   Connection con;
	String url="jdbc:mysql://localhost:3306/back_db";
    ResultSet rst;
	
	JLabel name,qantity,price;
	JButton create,update,delete,search,cancel;
	JTextField text_name, text_qantity, text_price;
	
	JPanel panel=new JPanel();
	
	
	
	public Product() {
		this.setTitle("Insert the product");
		// these are label of the textfields
		name=new JLabel("name:");
		qantity=new JLabel("qantity:");
		price=new JLabel("price:");
		
		
		// these are textfields where we will type information
		text_name=new JTextField();
		text_qantity=new JTextField();
		text_price=new JTextField();
		
		
		// these are button for doing actions
		create=new JButton("create");
		update=new JButton("Update");
		delete=new JButton("Delete");
		search=new JButton("Search");
		cancel=new JButton("Cancel");
		name.setBounds(20,20,60,40);
		qantity.setBounds(20,60,60,40);
		price.setBounds(20,100,60,40);
		
		text_name.setBounds(90,20,300,30);
		text_qantity.setBounds(90,60,300,30);
		text_price.setBounds(90,100,300,30);
		
		create.setBounds(20,230,80,30);
		update.setBounds(110,230,80,30);
		delete.setBounds(200,230,80,30);
		search.setBounds(290,230,80,30);
		cancel.setBounds(380,230,80,30);
		// add content to the panel
		panel.setLayout(null);
		panel.setBackground(Color.green);
		panel.add(name);
		panel.add(qantity);
		panel.add(price);
		panel.add(text_name);
		panel.add(text_qantity);
		panel.add(text_price);
		
		panel.add(create);
		panel.add(search);
		panel.add(update);
		panel.add(delete);
		panel.add(cancel);
		 getContentPane().add(panel);
		this.setSize(500,330);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				insert();
								
			}
		});
		search.addActionListener(new ActionListener() {//this is an event of clicking the button search
			
			@Override
			public void actionPerformed(ActionEvent e) {
				select();// this is a function call of selecting from the database
								
			}
		});
     update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
								
			}
		});
    delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				delete();
								
			}
		});
	cancel.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			new Myemployee();
			dispose();
			
		}
	});
	}
	
	 public void insert(){// function for inserting a new product
		 String sql1="INSERT INTO product(`name`, `qantity`, `price`)"
	                + "VALUES(?,?,?)";
	      
	        try {	              
	        	con=DriverManager.getConnection(url,"root","");
                pr=con.prepareStatement(sql1);  
	              
	            pr.setString(1,text_name.getText());
	            pr.setString(2,text_qantity.getText());
	            pr.setString(3,text_price.getText());
	           
	           
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
	 public void select(){// function of searching a product
	       
         try {
               String slct="SELECT *FROM product WHERE name='"+text_name.getText()+"'";
             con=DriverManager.getConnection(url,"root","");
            
             pr=con.prepareStatement(slct);
             rst=pr.executeQuery();
           
             if(rst.next()){                   
                text_name.setText(rst.getString("Name"));
                 text_qantity.setText(rst.getString("qantity"));
                  text_price.setText(rst.getString("price"));
                  
             }
             else {
            	 JOptionPane.showMessageDialog(null,"Searched Record name found!!");
             }
       } catch (Exception e) {
             System.out.println(e);
        }
    }
public void delete(){// function for deleting a product
         
         String sql="DELETE from product where name='"+text_name.getText()+"'";
         
         PreparedStatement pr;
        try {
            con=DriverManager.getConnection(url,"root","");
            pr = con.prepareStatement(sql);
              
              if(pr.execute()) {
            	  JOptionPane.showMessageDialog(null,"wow deleted succefully!!");
              }
              else {
            	  JOptionPane.showMessageDialog(null,"Record not found!!");
              }
             
              
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"Not Deleted!!");
        }

}
public void update(){// function for updating a worker
    
    
    String upd="UPDATE product SET qantity=?"
            + ",price=? WHERE name=?";
          
    try {
        con=DriverManager.getConnection(url,"root","");
        pr=con.prepareStatement(upd);
        
        pr.setString(1,text_qantity.getText());
        pr.setString(2,text_price.getText());
        pr.setString(3,text_name.getText());
       
    
        JOptionPane openJ=new JOptionPane();
        int showJ=openJ.showConfirmDialog(null,"Dou you want to Update this Record","UPDATE",
                JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(showJ==JOptionPane.OK_OPTION){
            pr.executeUpdate();
            JOptionPane.showMessageDialog(null,"UPDATED Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
        	 JOptionPane.showMessageDialog(null,"Update cancelled Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,e);
    }
}}

