package backery;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;  
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import backery.Mymanager;

public class Order extends JFrame {
    static Connection con = null;
    PreparedStatement pr = null;
    String user = "root";
    String pass = "";
    String url = "jdbc:mysql://localhost:3306/back_db";
    ResultSet rst;
    JLabel order_id, cust_name, date, total_amount, pstatus, d_status;
    JButton create, update, delete, search, cancel;
    JTextField text_order_id, text_cust_name, text_date, text_total_amount;
    JComboBox<String> text_pstatus = new JComboBox<>();
    JComboBox<String> text_d_status = new JComboBox<>();
    JPanel panel = new JPanel();

    public Order() {
        this.setTitle("My Order Form");

        // Labels for the text fields
        order_id = new JLabel("Order ID:");
        cust_name = new JLabel("Customer Name:");
        date = new JLabel("Date:");
        total_amount = new JLabel("Total Amount:");
        pstatus = new JLabel("Payment Status:");
        d_status = new JLabel("Delivery Status:");

        // Text fields for input
        text_order_id = new JTextField();
        text_cust_name = new JTextField();
        text_date = new JTextField();
        text_total_amount = new JTextField();

        // ComboBox for status selection
        text_pstatus.addItem("paid");
        text_pstatus.addItem("pending");

        text_d_status.addItem("delivered");
        text_d_status.addItem("progress");

        // Buttons for actions
        create = new JButton("Create");
        update = new JButton("Update");
        delete = new JButton("Delete");
        search = new JButton("Search");
        cancel = new JButton("Cancel");

        order_id.setBounds(20, 20, 150, 20);
        cust_name.setBounds(20, 45, 150, 20);
        date.setBounds(20, 70, 150, 20);
        total_amount.setBounds(20, 95, 150, 20);
        pstatus.setBounds(20, 120, 150, 20);
        d_status.setBounds(20, 145, 150, 20);

        text_order_id.setBounds(140, 20, 150, 20);
        text_cust_name.setBounds(140, 45, 150, 20);
        text_date.setBounds(140, 70, 150, 20);
        text_total_amount.setBounds(140, 95, 150, 20);
        text_pstatus.setBounds(140, 120, 150, 20);
        text_d_status.setBounds(140, 145, 150, 20);

        create.setBounds(20, 300, 80, 30);
        update.setBounds(110, 300, 80, 30);
        delete.setBounds(200, 300, 80, 30);
        search.setBounds(290, 300, 80, 30);
        cancel.setBounds(380, 300, 80, 30);

        create.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insert();
            }
        });

        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                select();
            }
        });

        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                update();
            }
        });

        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Mymanager();
                dispose();
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delete();
                text_order_id.setText(null);
                text_cust_name.setText(null);
                text_date.setText(null);
                text_total_amount.setText(null);
                text_pstatus.setSelectedItem(null);
                text_d_status.setSelectedItem(null);
            }
        });

        // Add content to the panel
        panel.setLayout(null);
        panel.setBackground(Color.GREEN);
        panel.add(order_id);
        panel.add(cust_name);
        panel.add(date);
        panel.add(total_amount);
        panel.add(pstatus);
        panel.add(d_status);
        panel.add(text_order_id);
        panel.add(text_cust_name);
        panel.add(text_date);
        panel.add(text_total_amount);
        panel.add(text_pstatus);
        panel.add(text_d_status);
        panel.add(create);
        panel.add(search);
        panel.add(update);
        panel.add(delete);
        panel.add(cancel);
        getContentPane().add(panel);

        this.setSize(500, 380);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void insert() {
        try {
            String sql = "INSERT INTO `order` (order_id, cust_name, date, total_amount, pstatus, d_status) VALUES (?, ?, ?, ?, ?, ?)";
            con = DriverManager.getConnection(url, user, pass);
            pr = con.prepareStatement(sql);
            pr.setString(1, text_order_id.getText());
            pr.setString(2, text_cust_name.getText());
            pr.setString(3, text_date.getText());
            pr.setString(4, text_total_amount.getText());
            pr.setString(5, text_pstatus.getSelectedItem().toString());
            pr.setString(6, text_d_status.getSelectedItem().toString());

            int result = pr.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Order created successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to create order", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Failed to create order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void select() {
        try {
            String sql = "SELECT * FROM `order` WHERE order_id=?";
            con = DriverManager.getConnection(url, user, pass);
            pr = con.prepareStatement(sql);
            pr.setString(1, text_order_id.getText());
            rst = pr.executeQuery();

            if (rst.next()) {
                text_cust_name.setText(rst.getString("cust_name"));
                text_date.setText(rst.getString("date"));
                text_total_amount.setText(rst.getString("total_amount"));
                text_pstatus.setSelectedItem(rst.getString("pstatus"));
                text_d_status.setSelectedItem(rst.getString("d_status"));
            } else {
                JOptionPane.showMessageDialog(null, "Order not found", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Failed to search order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void delete() {
        try {
            String sql = "DELETE FROM `order` WHERE order_id=?";
            con = DriverManager.getConnection(url, user, pass);
            pr = con.prepareStatement(sql);
            pr.setString(1, text_order_id.getText());

            int result = pr.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Order deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete order", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Failed to delete order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void update() {
        try {
            String sql = "UPDATE `order` SET order_id=?, cust_name=?, date=?, total_amount=?, pstatus=?, d_status=? WHERE order_id=?";
            con = DriverManager.getConnection(url, user, pass);
            pr = con.prepareStatement(sql);
            pr.setString(1, text_order_id.getText());
            pr.setString(2, text_cust_name.getText());
            pr.setString(3, text_date.getText());
            pr.setString(4, text_total_amount.getText());
            pr.setString(5, text_pstatus.getSelectedItem().toString());
            pr.setString(6, text_d_status.getSelectedItem().toString());
            pr.setString(7, text_order_id.getText());

            int result = pr.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Order updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update order", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Failed to update order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
