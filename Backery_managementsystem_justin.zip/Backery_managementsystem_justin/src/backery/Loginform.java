package backery;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;

import backery.Myform;
import backery.Mymanager;
import backery.Myemployee;


public class Loginform  extends JFrame {

    private JButton Login = new JButton("Login");
    private JButton register = new JButton("Register");
       
            Connection con = null;
            PreparedStatement pr;
            ResultSet rst;
              
    public Loginform () {
         

      
        this.setTitle("Loginform");
        this.setSize(420, 200);// to set the size of Loginform
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel pan = new JPanel();
        JTextField text = new JTextField(null);
        JPasswordField pass1 = new JPasswordField();// to make the password hidden 
        
        JPanel panel1JPanel=new JPanel();
       // the for right date and time
        panel1JPanel.setBounds(250,20,150,60);
        
        panel1JPanel.setLayout(null);
      
            

        JLabel user = new JLabel("Username:");
        JLabel password = new JLabel("Password:");

        // the size of labels
        user.setBounds(20, 25, 80, 30);
        password.setBounds(20, 55, 80, 30);
        //the size of textfield 
        text.setBounds(90, 30, 150, 25);
        pass1.setBounds(90, 60, 150, 25);


        // getting the tetx into our textfield and passwordfield
        //setting the column of textfield
        text.setColumns(10);
        pass1.setColumns(10);

        // giving the action to be done by the the button
        Login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String url="jdbc:mysql://localhost:3306/back_db";
                
              
                 
                 
                String sql="SELECT *FROM register WHERE  UserName=? AND PassWord=?";   
                try {
                   
                    con=DriverManager.getConnection(url,"root","");
                    pr=con.prepareStatement(sql);
                    pr.setString(1,text.getText());
                     pr.setString(2, pass1.getText());
                     
                    rst=pr.executeQuery();
                    if(rst.next()){
                    	
                    	
                    //	if(rst.getString("").equals("")) {
                    		String name = "userman!";
                            pan.setBackground(Color.green);
                             JOptionPane.showMessageDialog(null, "successfully logged in " + name, "Loginform", JOptionPane.INFORMATION_MESSAGE);
                             new Mymanager();
                           
                             dispose();
                    	
                    	//}
                    	

                      
                    } 

                    else{
                       pan.setBackground(Color.red);
                        String phrase = "Wrong password";
                        JOptionPane.showMessageDialog(null, "Unsuccessfully logged in==> " + phrase, "Loginform", JOptionPane.INFORMATION_MESSAGE);
                     
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog( null, ex);
                }
              
                        
                        
                        
            
                }});
        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	new Register();
            	dispose();
            }});

        Login.setBounds(200, 90, 80, 25);
        register.setBounds(80, 90, 100, 25);

        // passing the label and textfield to the pannel
        pan.setLayout(null);
       
        pan.add(panel1JPanel);
        pan.add(user);
        pan.add(text);

        pan.add(password);
        pan.add(pass1);
        pan.add(register, BorderLayout.SOUTH);
        pan.add(Login, BorderLayout.SOUTH);
        // passing the pannel to the frame
        this.getContentPane().add(pan);

          setVisible(true);
    }
    private  void timer(){
           
        new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            }
        }
        ).start();
    }
  public static void main (String[]args) {
	  new Loginform();
  }

}
