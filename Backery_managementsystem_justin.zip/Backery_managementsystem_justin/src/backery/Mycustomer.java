package backery;

import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import backery.Customer;

public class Mycustomer extends JFrame {
	PreparedStatement pr;
	static   Connection con;
	String url="jdbc:mysql://localhost:3306/back_db";
    ResultSet rst;
	JLabel name,gender,phone_number,address,product,quantity,price;
	JButton create,update,delete,search,cancel,calculate;
	JTextField text_name, text_gender, text_phone_number, text_address,text_price,text_quantity;
	JComboBox text_product=new JComboBox();
	JPanel panel=new JPanel();
	String stor;
	Double qt;
	public Mycustomer() {
		this.setTitle("our customer registration");
		// these are label of the textfields
		name=new JLabel("name");
		gender=new JLabel("gender");
		phone_number=new JLabel("phone_number");
		address=new JLabel("address");
		product=new JLabel("product name");
		quantity=new JLabel("quantity");
		price=new JLabel("price");
		// these are textfields where we will type information
		text_name=new JTextField();
		text_gender=new JTextField();
		text_phone_number=new JTextField();
		text_address=new JTextField();
		text_price=new JTextField();
		text_quantity=new JTextField();
//		text_name.getText();
//		text_gender.getText();
//		text_phone_number.getText();
//		text_address.getText();
//		text_price.getText();
//		text_quantity.getText();
//		
		 String sel="SELECT *FROM product";
		 
		 try {
			con=DriverManager.getConnection(url,"root","");
			
			 PreparedStatement pr1=con.prepareStatement(sel);
			 
			 ResultSet rst1=pr1.executeQuery();
			 
			 while(rst1.next()) {
				 
				 stor=rst1.getString("name");
				  
				 text_product.addItem(stor); 
			
			 }
			 

//			
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 try {
			 
			calculate=new JButton("Calcutate");
			 
			 String sel1="SELECT *FROM product WHERE name='"+text_product.getToolkit()+"' AND quantity='"+text_quantity.getText()+"'";
			 PreparedStatement pr2=con.prepareStatement(sel);
						 
						 ResultSet rst2=pr2.executeQuery();
						 
						 while(rst2.next()) {
							 
							qt=Double.parseDouble(rst2.getString("price"));
							 calculate.addActionListener(new ActionListener() {
									
									@Override
									public void actionPerformed(ActionEvent e) {
										
										Double com=Double.parseDouble(text_quantity.getText());
										Double result=qt*com;			
								String str=String.valueOf(result);
								text_price.setText(str);
									}
								});
						
						 }
						 
						
						
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		// these are button for doing actions
		create=new JButton("create");
		update=new JButton("Update");
		delete=new JButton("Delete");
		search=new JButton("Search");
		cancel=new JButton("Cancel");
		name.setBounds(20,20,60,40);
		gender.setBounds(20,60,60,40);
		phone_number.setBounds(20,100,60,40);
		address.setBounds(20,140,60,40);
		product.setBounds(20,180,60,40);
		quantity.setBounds(20,220,60,40);
		price.setBounds(20,260,60,40);
		text_name.setBounds(90,20,300,30);
		text_gender.setBounds(90,60,300,30);
		text_phone_number.setBounds(90,100,300,30);
		text_address.setBounds(90,140,300,30);
		text_product.setBounds(90,180,300,30);
		text_price.setEditable(false);
		text_quantity.setBounds(90,220,300,30);
		text_price.setBounds(90,260,300,30);
		create.setBounds(20,310,80,30);
		update.setBounds(20,310,80,30);
		delete.setBounds(110,310,80,30);
		search.setBounds(200,310,80,30);
		cancel.setBounds(290,310,80,30);
		calculate.setBounds(380,310,100,30);
		// add content to the panel
		panel.setLayout(null);
		panel.setBackground(Color.green);
		panel.add(name);
		panel.add(calculate);
		panel.add(gender);
		panel.add(phone_number);
		panel.add(address);
		panel.add(product);
		panel.add(quantity);
		panel.add(price);
		panel.add(text_name);
		panel.add(text_gender);
		panel.add(text_phone_number);
		panel.add(text_address);
		panel.add(text_product);
		panel.add(text_quantity);
		panel.add(text_price);
	panel.add(create);
		panel.add(search);
		panel.add(update);
		panel.add(delete);
		panel.add(cancel);
		
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				insert();
				
			}
		});
		search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				select();
			}
		});
		
		update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				update();
			}
		});
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				delete();
			}
		});
		 cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Myemployee();
				dispose();
			}
		});
		 getContentPane().add(panel);
		this.setSize(620,400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	 public void insert(){// function for inserting a new staff
		 String sql2="INSERT INTO customer(name, gender, phone_number, address, product, quantity, price)"
	                + "VALUES(?,?,?,?,?,?,?)";
	      
	        try {
	        	con=DriverManager.getConnection(url,"root",""); 
		           pr= con.prepareStatement(sql2); 
	           pr.setString(1,text_name.getText());
	            pr.setString(2,text_gender.getText());
	            pr.setString(3,text_phone_number.getText());
	            pr.setString(4,text_address.getText());
	            pr.setString(5,text_product.getSelectedItem().toString());
	            pr.setString(6,text_quantity.getText());
            pr.setString(7,text_price.getText());
           
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
	 public void select(){// function of searching a customer
	       
         try {
        	 
        	String slct="SELECT *FROM customer WHERE name='"+text_name.getText()+"'";
             con=DriverManager.getConnection(url,"root","");
            
             pr=con.prepareStatement(slct);
             rst=pr.executeQuery();
           
             if(rst.next()){                   
                text_name.setText(rst.getString("name"));
                 text_gender.setText(rst.getString("gender"));
                  text_phone_number.setText(rst.getString("phone_number"));
                   text_address.setText(rst.getString("address"));
                   text_product.setSelectedItem(rst.getString("product"));
                     text_quantity.setText(rst.getString("quantity"));
                      text_price.setText(rst.getString("price"));

             }
       } catch (Exception e) {
             System.out.println(e);
        }
    }
	 
	
	 public void update(){// function for inserting a new patient
		 
		
		 
		 
		 String sql2="UPDATE customer SET gender=?, phone_number=?, address=?, product=?, quantity=?, price=? WHERE name=?";
	      
	        try {
	        	con=DriverManager.getConnection(url,"root",""); 
		           pr= con.prepareStatement(sql2); 
	         
	            pr.setString(1,text_gender.getText());
	            pr.setString(2,text_phone_number.getText());
	            pr.setString(3,text_address.getText());
	            pr.setString(4,text_product.getSelectedItem().toString());
	            pr.setString(5,text_quantity.getText());
	            pr.setString(6,text_price.getText());
	            pr.setString(7,text_name.getText());
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
 public void delete(){// function for deleting a staff
         
         String sql="DELETE from customer where name='"+text_name.getText()+"'";
         
         PreparedStatement pr;
        try {
            con=DriverManager.getConnection(url,"root","");
            pr = con.prepareStatement(sql);
              //pr.execute();
              JOptionPane.showMessageDialog(null,"value deleted succefully!!");
              
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null," value Not Deleted!!");
        }
       
    }
	 
}

