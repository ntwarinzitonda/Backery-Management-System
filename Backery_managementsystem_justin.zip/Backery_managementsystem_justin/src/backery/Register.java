package backery;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
 
public class Register implements ActionListener {
    JFrame frame;
    String[] gender={"Male","Female"};
    JLabel nameLabel=new JLabel("NAME");
    JLabel genderLabel=new JLabel("GENDER");
    JLabel usernameLabel=new JLabel("USER NAMEE");
    JLabel passwordLabel=new JLabel("PASSWORD");
    JTextField nameTextField=new JTextField();
    JComboBox genderComboBox=new JComboBox(gender);
    JTextField usernameTextField=new JTextField();
    JPasswordField passwordField=new JPasswordField();
    JButton registerButton=new JButton("REGISTER");
    JButton resetButton=new JButton("RESET");
 
 
    Register()
    {
        createWindow();
        setLocationAndSize();
        addComponentsToFrame();
        actionEvent();
    }
    public void createWindow()
    {
        frame=new JFrame();
        frame.setTitle("Registration Form");
        frame.setBounds(40,40,380,250);
        frame.getContentPane().setBackground(Color.pink);
        frame.getContentPane().setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
    }
    public void setLocationAndSize()
    {
        nameLabel.setBounds(20,20,150,20);
        genderLabel.setBounds(20,45,150,20);
        usernameLabel.setBounds(20,70,150,20);
        passwordLabel.setBounds(20,95,150,20);
        
        nameTextField.setBounds(140,20,150,20);
        genderComboBox.setBounds(140,45,150,20);
        usernameTextField.setBounds(140,70,150,20);
        passwordField.setBounds(140,95,150,20);
       
        registerButton.setBounds(70,150,100,35);
        resetButton.setBounds(220,150,100,35);
    }
    public void addComponentsToFrame()
    {
        frame.add(nameLabel);
        frame.add(genderLabel);
       
        frame.add(usernameLabel);
        frame.add(passwordLabel);
        frame.add(usernameTextField);
        frame.add(nameTextField);
        frame.add(genderComboBox);
        
        frame.add(passwordField);
       
        frame.add(registerButton);
        frame.add(resetButton);
    }
    public void actionEvent()
    {
        registerButton.addActionListener(this);
        resetButton.addActionListener(this);
    }
 
 
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==registerButton)
        {
            try {
                //Creating Connection Object
             Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/back_db","root","");
               
            	
            	//Preapared Statement
                PreparedStatement Pstatement=connection.prepareStatement("insert into register values(?,?,?,?)");
                //Specifying the values of it's parameter
                Pstatement.setString(1,nameTextField.getText());
               
                Pstatement.setString(2,genderComboBox.getSelectedItem().toString());
                Pstatement.setString(3,usernameTextField.getText());
                Pstatement.setString(4,passwordField.getText());
             
                //Checking for the Password match
//                if(passwordField.getAction("") )
                {
                    //Executing query
                    Pstatement.executeUpdate();
                    JOptionPane.showMessageDialog(null,"Data Registered Successfully");
                    frame.dispose();
                    
                    Loginform rp = new Loginform();
                    setVisible(false);
                    rp.setVisible(true);
              
                }}
             catch (SQLException e1) {
                e1.printStackTrace();
            }
 
 
        }
        if(e.getSource()==resetButton)
        {
            //Clearing Fields
            nameTextField.setText("");
            genderComboBox.setSelectedItem("Male");
           
            passwordField.setText("");
          
        }}
      
            public static void main(String[] args)
            {
                new Register();
            }
			public void setTitle(String string) {
				// TODO Auto-generated method stub
				
			}
			public void setLocationRelativeTo(Object object) {
				// TODO Auto-generated method stub
				
			}
			public void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
   

 
    }
   
