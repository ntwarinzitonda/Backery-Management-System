package backery;

import javax.swing.SwingUtilities;

import backery.Loginform;

public class Mainform {
	
	public static void main(String[] args) {   
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	
                 Loginform ln=new Loginform();

            }
        });
      
    }
}
