package backery;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import backery.Employee;
import backery.Product;
import backery.Order;
import backery.Customer;



public class Myorder extends JFrame{
	JButton employee=new JButton("employee");
	JButton customer=new JButton("customer");
	JButton product=new JButton("product");
	JButton order=new JButton("order");
	JPanel panel1=new JPanel();
public Myorder() {
	
//	doctor.setBounds(20, 50, 200, 60);
	customer.setBounds(20, 50, 200, 60);
	product.setBounds(240, 50, 200, 60);
	employee.setBounds(20, 50, 200, 60);
	panel1.setBackground(Color.green);
	panel1.setLayout(null);
//	panel1.add(doctor);
	panel1.add(customer);
	panel1.add(product);
	panel1.add(employee);
	getContentPane().add(panel1);
	this.setTitle("table");
	this.setSize(500,300);
	this.setLocationRelativeTo(null);
	
	this.setVisible(true);
	
	employee.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			employee();
			dispose();
			
		}
	});
	customer.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			customer();
			dispose();
			
		}
	});
	product.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			product();
			dispose();
			
		}
	});
order.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			order();
			dispose();
			
		}
	});
}


protected void order() {
	Order s=new Order();
	
}


//function of calling the Doctor class
public void employee() {
	Employee emp=new Employee();
}
//function of calling the Patient class
public void customer() {
	Mycustomer my=new Mycustomer();
}
//function of calling the Drugs class
public void product() {
	Product pr=new Product();
}

}