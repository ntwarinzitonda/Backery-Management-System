package backery;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import backery.Mymanager;

public class Employee extends JFrame {
	

	 static Connection con = null;
	    PreparedStatement pr=null;
	     String user="Root";
	         String pass ="";
	         String url="jdbc:mysql://localhost:3306/back_db";
	         ResultSet rst;
	JLabel name,gender,phone_number,address,type,username,password,workers_id;
	JButton create,update,delete,search,cancel;
	JTextField text_name, text_gender, text_phone_number, text_address,text_username,text_password,text_workers_id;
	JComboBox text_type=new JComboBox();
	JPanel panel=new JPanel();
	
	
	public Employee() {
		this.setTitle("backery workers registration");
		// these are label of the textfields
		name=new JLabel("name:");
		gender=new JLabel("Gender:");
		phone_number=new JLabel("phone_number:");
		address=new JLabel("Address:");
		type=new JLabel("Type:");
		username=new JLabel("Username");
		password=new JLabel("Password");
		workers_id=new JLabel("workers_id");
		// these are textfields where we will type information
		text_name=new JTextField();
		text_gender=new JTextField();
		text_phone_number=new JTextField();
		text_address=new JTextField();
		text_username=new JTextField();
		text_password=new JTextField();
		text_workers_id=new JTextField();
		text_type.addItem("manager");
		text_type.addItem("simple seller");
		text_type.addItem("cooker");
		text_type.addItem("waiter");
		
		
		// these are button for doing actions
		create=new JButton("create");
		update=new JButton("Update");
		delete=new JButton("Delete");
		search=new JButton("Search");
		cancel=new JButton("Cancel");
		name.setBounds(20,20,150,20);
		gender.setBounds(20,45,150,20);
		phone_number.setBounds(20,70,150,20);
		address.setBounds(20,95,150,20);
		type.setBounds(20,120,150,20);
		username.setBounds(20,145,150,20);
		password.setBounds(20,170,150,20);
		workers_id.setBounds(20,195,150,20);
		
		text_name.setBounds(140,20,150,20);
		text_gender.setBounds(140,45,150,20);
		text_phone_number.setBounds(140,70,150,20);
		text_address.setBounds(140,95,150,20);
		text_type.setBounds(140,120,150,20);
		text_username.setBounds(140,145,150,20);
		text_password.setBounds(140,170,150,20);
		text_workers_id.setBounds(140,195,150,20);
	
		create.setBounds(20,300,80,30);
		update.setBounds(110,300,80,30);
		delete.setBounds(200,300,80,30);
		search.setBounds(290,300,80,30);
		cancel.setBounds(380,300,80,30);
		
		//getting information from the interface
		
		text_name.getText();
		text_gender.getText();
		text_phone_number.getText();
		text_address.getText();
		text_type.getSelectedItem();
		text_username.getText();
		text_password.getText();
		text_workers_id.getText();
		
		  create.addActionListener(new ActionListener() {// creating a worker
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                 insert();
	                }
	         });
		  
		  search.addActionListener(new ActionListener() {// searching record
	            @Override
	            public void actionPerformed(ActionEvent e) {
	               select();
	            
	            }
	        });
	      
	           update.addActionListener(new ActionListener() {//updating record
	            @Override
	            public void actionPerformed(ActionEvent e) {
	               
	             update();
	            }
	        });
	           cancel.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					new Mymanager();
					dispose();
					
				}
			});
	          
	       
	           delete.addActionListener(new ActionListener() {
	               @Override
	               public void actionPerformed(ActionEvent e) {
	                   try {
	                         delete();
	                         text_name.setText(null);
	                         text_gender.setText(null);
	                          text_phone_number.setText(null);
	                           text_address.setText(null);
	                            text_type.setSelectedItem(null);
	                             text_username.setText(null);
	                              text_password.setText(null);
	                              text_workers_id.setText(null);

	                   } 
	                   catch (Exception ex) {
	                       System.out.println("Invalide");
	                   }
	                 
	               }
	           });
		
		
		
		
		
		// add content to the panel
		panel.setLayout(null);
		panel.setBackground(Color.green);
		panel.add(name);
		panel.add(gender);
		panel.add(phone_number);
		panel.add(address);
		panel.add(type);
		panel.add(workers_id);
		
		panel.add(text_name);
		panel.add(text_gender);
		panel.add(text_phone_number);
		panel.add(text_address);
		panel.add(text_type);
		panel.add(text_workers_id);
		panel.add(username);
		panel.add(password);
		panel.add(text_username);
		panel.add(text_password);
		
		panel.add(create);
		panel.add(search);
		panel.add(update);
		panel.add(delete);
		panel.add(cancel);
		 getContentPane().add(panel);
		this.setSize(500,380);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	 public void insert(){// function for inserting a new worker
	      
	        try {
	              
	          String sql="INSERT INTO workers(name, gender, phone_number, type, address, username, Password,workers_id)" + "VALUES(?,?,?,?,?,?,?,?)";
	               
	         
	              con=DriverManager.getConnection(url,"root",""); 
	           pr= con.prepareStatement(sql);
	            pr.setString(1,text_name.getText());
	            pr.setString(2,text_gender.getText());
	            pr.setString(3,text_phone_number.getText());
	            pr.setString(4,text_type.getSelectedItem().toString());
	            pr.setString(5,text_address.getText());
	            pr.setString(6,text_username.getText());
	            pr.setString(7,text_password.getText());
	            pr.setString(8,text_workers_id.getText());
	           
	            
	            int str=0;
	                    
	            if (str==JOptionPane.OK_OPTION){
	               pr.execute();
	                JOptionPane.showMessageDialog(null,"saved successfully","Save",JOptionPane.OK_CANCEL_OPTION);
	            }
	           
	          } catch (SQLException ex) {    
	          JOptionPane.showMessageDialog(null,"Not saved !!!"+ex);
	        }
	       
	    }
	 public void select(){// function of searching a worker
		
		String show;
         try {
               String slct="SELECT *FROM workers WHERE name='"+text_name.getText()+"'";
             con=DriverManager.getConnection(url,"root","");
            
             pr=con.prepareStatement(slct);
             rst=pr.executeQuery();
           
             while(rst.next()){                   
                text_name.setText(rst.getString("name"));
                 text_gender.setText(rst.getString("gender"));
                  text_phone_number.setText(rst.getString("phone_number"));
                   text_address.setText(rst.getString("address"));
                   show=rst.getString("type");
                    text_type.addItem(show);
                     text_username.setText(rst.getString("username"));
                      text_password.setText(rst.getString("Password"));
                      text_workers_id.setText(rst.getString("workers_id"));

             }
       } catch (Exception e) {
             System.out.println(e);
        }
    }
	 public void delete(){// function for deleting a worker
         
         String sql="DELETE from workers where workers_id='"+text_name.getText()+"'";
         
         PreparedStatement pr;
        try {
            con=DriverManager.getConnection(url,"root","");
            pr = con.prepareStatement(sql);
              pr.execute();
              JOptionPane.showMessageDialog(null,"value deleted succefully!!");
              
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null," value Not Deleted!!");
        }
       
    }
	    public void update(){// function for updating a worker
	    	 String sql2="UPDATE customer SET workers_id=?, gender=?, type=?, address=?, username=? , password, phone_number=?=?WHERE name=?";
	           
	            String upd="UPDATE workers SET "
	                    + "gender=?,"
	                    + "workers_id=?,"
	                    + "phone_number=?,address=?,"
	                    + "type=?,Username=?,"
	                    + "Password=?  WHERE name=?";
	            try {
	                con=DriverManager.getConnection(url,"root","");
	                pr=con.prepareStatement(upd);
	                
	              
	                pr.setString(1,text_name.getText());
		            pr.setString(2,text_gender.getText());
		            pr.setString(3,text_phone_number.getText());
		            pr.setString(4,text_type.getSelectedItem().toString());
		            pr.setString(5,text_address.getText());
		            pr.setString(6,text_username.getText());
		            pr.setString(7,text_password.getText());
		            pr.setString(8,text_workers_id.getText());
		           
	            
	         
	             
	            
	                JOptionPane openJ=new JOptionPane();
	                int showJ=openJ.showConfirmDialog(null,"Dou you want to Update this Record","UPDATE",
	                        JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
	                if(showJ==JOptionPane.OK_OPTION){
	                    pr.executeUpdate();
	                    JOptionPane.showMessageDialog(null,"UPDATED Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
	                }
	                else {
	                	 JOptionPane.showMessageDialog(null,"Update cancelled Successfully","UPDATE",JOptionPane.INFORMATION_MESSAGE);
	                }
	                
	            } catch (Exception e) {
	                JOptionPane.showMessageDialog(null,e);
	            }
	        
	    }
	 
    

}
