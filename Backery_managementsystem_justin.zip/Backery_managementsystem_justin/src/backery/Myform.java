package backery;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import backery.Employee;
import backery.Product;
import backery.Customer;

public class Myform extends JFrame{
	JButton employee=new JButton("employee");
	JButton customer=new JButton("customer");
	JButton product=new JButton("product");
	JButton order=new JButton("order");
	JButton sales=new JButton("sales");
	JButton ingredient=new JButton("ingredient");
	
	JPanel panel1=new JPanel();
public Myform() {
	
	employee.setBounds(20, 50, 200, 60);
	customer.setBounds(240, 50, 200, 60);
	product.setBounds(130, 140, 200, 60);
	order.setBounds(340, 140, 200, 60);
	sales.setBounds(130, 230, 200, 60);
	ingredient.setBounds(340, 230, 200, 60);
	panel1.setBackground(Color.green);
	panel1.setLayout(null);

	panel1.add(customer);

	getContentPane().add(panel1);
	this.setTitle("table");
	this.setSize(500,300);
	this.setLocationRelativeTo(null);
	
	this.setVisible(true);
	
//	doctor.addActionListener(new ActionListener() {
//		
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			
//			
//		}
//	});
	customer.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			customer();
			dispose();
			
		}
	});
//	drugs.addActionListener(new ActionListener() {
//		
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			drugs();
//			dispose();
//			
//		}
//	});
}


//function of calling the employee class
public void employee() {
	Employee emp=new Employee();
}
//function of calling the customer class
public void customer() {
	Customer my=new Customer();
}
//function of calling the product class
public void product() {
	Product pr=new Product();
}
//function of calling the order class
public void order() {
	Order pr=new Order();
}
//function of calling the sales class
public void sales() {
	Sales pr=new Sales();
}
//function of calling the ingredient class
public void ingredient() {
	Ingredient pr=new Ingredient();
}


}
