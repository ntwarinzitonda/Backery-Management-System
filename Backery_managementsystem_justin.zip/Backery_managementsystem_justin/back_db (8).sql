-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:49 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `back_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `name` varchar(35) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `phone_number` int(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `product` varchar(35) NOT NULL,
  `quantity` int(10) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`name`, `gender`, `phone_number`, `address`, `product`, `quantity`, `price`) VALUES
('kazoza', 'male', 89876, 'musanze', 'chocolate', 2, 2000),
('jules', 'male', 8766544, 'musanze', 'chocolate', 5, 5000),
('mali', 'male', 9865433, 'musanze', 'chocolate', 4, 4808);

-- --------------------------------------------------------

--
-- Table structure for table `ingredient`
--

CREATE TABLE `ingredient` (
  `ing_id` int(10) NOT NULL,
  `name` varchar(35) NOT NULL,
  `supplier` varchar(30) NOT NULL,
  `unit` varchar(26) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ingredient`
--

INSERT INTO `ingredient` (`ing_id`, `name`, `supplier`, `unit`, `price`, `quantity`) VALUES
(9, 'cocomber', 'baptiste', 'kilograms', 2000, 4),
(99, 'iwa', 'koko', 'kilograms', 1000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(10) NOT NULL,
  `cust_name` varchar(35) NOT NULL,
  `date` varchar(20) NOT NULL,
  `total_amount` int(10) NOT NULL,
  `d_status` varchar(35) NOT NULL,
  `pstatus` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `cust_name`, `date`, `total_amount`, `d_status`, `pstatus`) VALUES
(5, 'kala', '2/0/2022', 3000, 'delivered', 'paid'),
(8, 'koko', '12/06/2020', 3000, 'delivered', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `name` varchar(35) NOT NULL,
  `qantity` int(11) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`name`, `qantity`, `price`) VALUES
('kake', 4, 500),
('chocolate', 20, 1000),
('milk', 20, 1202),
('amandi', 30, 1500),
('chapati', 20, 14000);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `name` varchar(11) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `username` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`name`, `gender`, `username`, `password`) VALUES
('koko', 'oko', '0', 'Male'),
('jaja', 'Female', '0', 'oko'),
('fifi', 'Female', 'fake', '123'),
('Kaka', 'Male', 'Jas', '1234'),
('hulu', 'Male', 'nana', '1234'),
('iness', 'Female', 'nolo', '1234'),
('kala', 'Male', 'julu', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `tr_id` int(11) NOT NULL,
  `p_name` varchar(35) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `t_date` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`tr_id`, `p_name`, `quantity`, `total_amount`, `t_date`) VALUES
(7, 'banana', 3, 300, '2/05/2020'),
(8, 'kake', 5, 1300, ' 2/06/2020');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(30) NOT NULL,
  `password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('justin', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE `workers` (
  `workers_id` int(10) NOT NULL,
  `name` varchar(35) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `type` varchar(26) NOT NULL,
  `address` varchar(30) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` int(4) NOT NULL,
  `phone_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`workers_id`, `name`, `gender`, `type`, `address`, `username`, `password`, `phone_number`) VALUES
(2, 'ntwari', 'male', 'manager', 'musanze', 'nzitonda', 1234, 78499020),
(8, 'nono', 'male', 'cooker', 'musanze', 'lana', 1234, 876543),
(7, 'koko', 'male', 'waiter', 'kigali', 'lolo', 1234, 786543),
(2, 'chance', 'femal', 'simple seller', 'huye', 'asia', 1234, 786554),
(6, 'nala', 'femal', 'cooker', 'ribavu', 'hli', 1234, 8765478),
(7, 'koo', 'femal', 'waiter', 'musanze', 'kulu', 1234, 8765432);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
